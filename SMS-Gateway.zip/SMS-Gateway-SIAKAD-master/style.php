  .page-header{
    background-color: #ace296;
    /*background: #408AD4;
    background: -webkit-gradient(linier,left top,left bottom,from(#408AD4),to(#00264C));
    background: -moz-linear-gradient(bottom, #dff0d8, #00264C);*/
    padding-bottom: 10px;
    padding-top: 15px;
    margin: 0;
    border-bottom: 0px;
    width: 
  }
  body{
    background-color: rgb(242, 253, 242);
  }
  .navbar-inverse {
    background-color: #154417;
    border-color: #b2bbb0;
    color: #fff;
  }

  .navbar{
    color: #eaf;
  }
  .navbar-collapse{
    color: #fff;
  }
  .navbar-header{
    color: #fff;
  }
  .dropdown-menu{
    background-color: #dff0d8;
    padding-top: 5px;
    padding-bottom: 5px;
  }
  .jumbotron{
    background-color: #eee;
    padding-top: 10px;
    padding-bottom: 10px;
    padding-left: 5px;
    vertical-align: left;
  }
  .alert-success{
    color: #154417;
    background-color: #ace296;
    border-color: #58ec5e;
  }
  .space{
    width: 16px;
    padding: 0px;

  }
  .spasi{
    width: 172px;
  }
  .status{
    text-align: right;
    padding-right: 0;
  }
  .btn-primary.active, .btn-primary:active, .btn-primary:hover, .btn-primary.active:hover, .btn-primary:active:hover, .open > .dropdown-toggle.btn-primary {
    color: #FFF;
    background-color: rgba(21, 68, 23, 0.6);
    border-color: rgba(21, 68, 23, 0.74);
    padding-bottom: 10px;
    padding-top: 10px;
  }
  .btn-primary {
    color: #154417;
    background-color: #d2efc6;
    border-color: #008000;
    padding-bottom: 10px;
    padding-top: 10px;
  }
  .isi, .menu{
    margin-bottom: 15px;
  }
  a.tombol{
    background-color: white;
    color: #154417;
    padding-top: 5px;
    padding-bottom: 5px;
  }
  a.tombol:hover,.tombol.active{
    background-color: #ace296;
    color: white;
    border-color: #ace296;
  }
  a.tombol.active:hover{
    background-color: #ace296;
    color: #154417;
    border-color: #154417;
  }
  .navbar-menu {
    color: white;
  }
  .radius{
    border-radius: 100%;
    padding: 3px 8px 3px 8px;
  }
  .modal-content{
    background-color: white;
  }
  .form-data{
    padding: 0 30px 50px 20px;
  }
  .judul-data{
    padding-left: 30px;
  }
  /*#menu-utama a,
  #menu-utama .navbar-header button{
    color: white;
    padding-top: 20px;
  }*/
  #menu-utama a.navbar-header:hover{
    color: #154417;
  }
  .navbar{
    margin-bottom: 15px;
  }
  .caption.hari{
    padding:0;
    
  }
  h6.hari{
    margin-top: 1px;
    margin-bottom: 4px;
    border-bottom: 1px solid white;
    padding-bottom: 2px;
  }
  .thumbnail.hari{
    background-color: #ace296;
    margin: 0;
  }
  .thumbnail.jadwal{
    margin: 1px;
  }
  div.col-md-2.hari{
    padding-left: 1px;
    padding-right: 1px;
  }
  div.row.isi-jadwal{
    margin-left: 0;
    margin-right: 0;
  }
  .btn-tambah-jadwal{
    padding-top: 2px;
    padding-bottom: 2px;
    margin-bottom: 2px;
    margin-top: 2px;
  }
  .btn-tambah-jadwal.aktif{
    color: green;
    font-size: 12pt;
  }