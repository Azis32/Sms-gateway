<?php
include "./bootstrap/costum/costum.css";
?>
<div class="panel panel-success">
			<div class="panel-heading">
				<h2 class="panel-title"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"> </span> Sistem Aplikasi Pemilihan Ketua BEM</h2>
			</div>
			<div class="panel-body">
				<div class="form-data">
			<h4 style="background-color:white; border-bottom:0">Pengguna Yth,</h4>
			<h5 style="margin:0 0 0 10px">Selamat Datang di <b style="color:green">Sistem Aplikasi Pemilihan Ketua BEM</b></h5>
			<h6 style="margin-left: 10px">Untuk menggunakan aplikasi secara maksimal</h6>
			<h6 style="margin-left: 10px">Silahakan anda mengikuti langkah-langkah sebagai berikut:</h6>
			<h6 style="margin-left: 10px"><b style="color:green">1. Aktifkan menu Server,</b></h6>
			<h6 style="margin-left: 10px"><b style="color:green">2.  Aktifkan menu Servis yang terdapat pada Aplikasi</b></h6>
			<h6 style="margin-left: 10px">Terima Kasih</h6></div>
			</div>
			</div>
