<!DOCTYPE html>
<html>
<head>
	<title>koneksi database terputus</title>
</head>
<body>
<script type="text/javascript">
	alert("koneksi terputus !!!");
</script>
<h2>Lihat Koneksi Database anda <a href="../"> refres halaman</a></h2>

</body>
</html>